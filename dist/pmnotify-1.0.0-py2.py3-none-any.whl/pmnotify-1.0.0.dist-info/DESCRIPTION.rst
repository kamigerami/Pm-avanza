Avanza PM Notification Project
=======================

This little python app will notify you whenever a new PM is available on https://www.avanza.se/placera/pressmeddelanden.html.
Tested on OS X Yosemite 10.10.5.

Requires the following modules :

beautifulsoup4 (4.3.2)
pync (1.6.1)


Instructions : 

Just run the app and it will run as a daemon in the background.


